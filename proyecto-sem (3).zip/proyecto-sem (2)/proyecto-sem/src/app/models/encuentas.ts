export class Encuentas {
}
