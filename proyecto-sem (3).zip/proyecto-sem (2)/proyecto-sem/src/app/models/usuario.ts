export class Usuario {
}
