import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { ConfigComponent } from './pages/config/config.component';
import { LoginComponent } from './pages/login/login.component';
import { EncuestasComponent } from './components/encuestas/encuestas.component';
import { PreguntasComponent } from './components/preguntas/preguntas.component';
import { TipoPreguntaComponent } from './components/tipo-pregunta/tipo-pregunta.component';   
import { AddEncuestasComponent } from './components/add-encuestas/add-encuestas.component';    
export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'encuestas', component: EncuestasComponent },
  { path: 'preguntas', component: PreguntasComponent },
  { path: 'tipo-pregunta', component: TipoPreguntaComponent },
  { path: 'config/:id', component: ConfigComponent },
  { path: 'add-encuestas', component: AddEncuestasComponent },
  { path: '**', redirectTo: 'login' },
];
