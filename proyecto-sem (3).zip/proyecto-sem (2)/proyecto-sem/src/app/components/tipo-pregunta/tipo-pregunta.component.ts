import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

interface TipoPregunta {
  titulo: string;
  descripcion: string;
  ejemplo: {
    pregunta: string;
    opciones: string[];
    escala: string[];
  };
  usos: string[];
  editando?: boolean;
  tipo: 'abierta' | 'cerrada' | 'multiple' | 'likert';
}

@Component({
  selector: 'app-tipo-pregunta',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './tipo-pregunta.component.html',
  styleUrl: './tipo-pregunta.component.sass'
})
export class TipoPreguntaComponent implements OnInit {
  tiposPreguntas: TipoPregunta[] = [];
  
  ngOnInit() {
    this.tiposPreguntas = [
      {
        titulo: 'Preguntas Abiertas',
        descripcion: 'Permiten al encuestado responder con sus propias palabras sin limitaciones.',
        ejemplo: {
          pregunta: '¿Qué opinas sobre el servicio recibido?',
          opciones: [],
          escala: []
        },
        usos: [
          'Para obtener opiniones detalladas',
          'Cuando se necesita información cualitativa',
          'Para entender el razonamiento detrás de una respuesta'
        ],
        editando: false,
        tipo: 'abierta'
      },
      {
        titulo: 'Preguntas Cerradas',
        descripcion: 'Ofrecen opciones específicas para elegir.',
        ejemplo: {
          pregunta: '¿Está satisfecho con el producto?',
          opciones: ['Sí', 'No'],
          escala: []
        },
        usos: [
          'Para obtener respuestas precisas',
          'Cuando se necesitan datos cuantitativos',
          'Para facilitar el análisis estadístico'
        ],
        editando: false,
        tipo: 'cerrada'
      },
      {
        titulo: 'Preguntas de Opción Múltiple',
        descripcion: 'Permiten seleccionar una o varias opciones de una lista.',
        ejemplo: {
          pregunta: '¿Qué redes sociales utilizas? (Selecciona todas las que apliquen)',
          opciones: ['Facebook', 'Twitter', 'Instagram'],
          escala: []
        },
        usos: [
          'Para preguntas con múltiples respuestas válidas',
          'Cuando hay opciones predefinidas claras',
          'Para facilitar la categorización'
        ],
        editando: false,
        tipo: 'multiple'
      },
      {
        titulo: 'Escala de Likert',
        descripcion: 'Mide el nivel de acuerdo o desacuerdo con una afirmación.',
        ejemplo: {
          pregunta: 'El producto cumple con mis expectativas.',
          opciones: [],
          escala: [
            'Totalmente en desacuerdo',
            'En desacuerdo',
            'Neutral',
            'De acuerdo',
            'Totalmente de acuerdo'
          ]
        },
        usos: [
          'Para medir actitudes y opiniones',
          'En evaluaciones de satisfacción',
          'Para obtener datos graduados'
        ],
        editando: false,
        tipo: 'likert'
      }
    ];
  }

  toggleEdicion(tipoPregunta: TipoPregunta) {
    tipoPregunta.editando = !tipoPregunta.editando;
  }

  eliminarTipoPregunta(index: number) {
    if (confirm('¿Estás seguro de que deseas eliminar este tipo de pregunta?')) {
      this.tiposPreguntas.splice(index, 1);
    }
  }

  agregarTipoPregunta() {
    const nuevaPregunta: TipoPregunta = {
      titulo: 'Nuevo Tipo de Pregunta',
      descripcion: 'Ingrese una descripción',
      ejemplo: {
        pregunta: 'Ingrese un ejemplo de pregunta',
        opciones: [],
        escala: []
      },
      usos: ['Ingrese un uso'],
      editando: true,
      tipo: 'abierta'
    };
    this.tiposPreguntas.push(nuevaPregunta);
  }

  agregarUso(tipoPregunta: TipoPregunta) {
    tipoPregunta.usos.push('Nuevo uso');
  }

  eliminarUso(tipoPregunta: TipoPregunta, index: number) {
    tipoPregunta.usos.splice(index, 1);
  }

  agregarOpcion(tipoPregunta: TipoPregunta, tipo: 'opciones' | 'escala') {
    if (tipo === 'opciones') {
      tipoPregunta.ejemplo.opciones.push('Nueva opción');
    } else {
      tipoPregunta.ejemplo.escala.push('Nuevo nivel');
    }
  }

  eliminarOpcion(tipoPregunta: TipoPregunta, index: number, tipo: 'opciones' | 'escala') {
    if (tipo === 'opciones') {
      tipoPregunta.ejemplo.opciones.splice(index, 1);
    } else {
      tipoPregunta.ejemplo.escala.splice(index, 1);
    }
  }

  actualizarOpcion(tipoPregunta: TipoPregunta, index: number, valor: string, tipo: 'opciones' | 'escala') {
    if (tipo === 'opciones') {
      tipoPregunta.ejemplo.opciones[index] = valor;
    } else {
      tipoPregunta.ejemplo.escala[index] = valor;
    }
  }

  onTipoChange(tipoPregunta: TipoPregunta) {
    // Resetear opciones y escala según el tipo
    tipoPregunta.ejemplo.opciones = [];
    tipoPregunta.ejemplo.escala = [];
    
    // Inicializar con valores por defecto según el tipo
    switch (tipoPregunta.tipo) {
      case 'cerrada':
        tipoPregunta.ejemplo.opciones = ['Sí', 'No'];
        break;
      case 'multiple':
        tipoPregunta.ejemplo.opciones = ['Opción 1', 'Opción 2', 'Opción 3'];
        break;
      case 'likert':
        tipoPregunta.ejemplo.escala = [
          'Totalmente en desacuerdo',
          'En desacuerdo',
          'Neutral',
          'De acuerdo',
          'Totalmente de acuerdo'
        ];
        break;
    }
  }
}