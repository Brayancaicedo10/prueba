import { Component } from '@angular/core';

@Component({
  selector: 'app-config',
  standalone: true,
  imports: [],
  templateUrl: './config.component.html',
  styleUrl: './config.component.sass'
})
export class ConfigComponent {

}
