export class Preguntas {
}
