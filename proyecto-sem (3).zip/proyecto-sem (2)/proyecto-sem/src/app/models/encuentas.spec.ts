import { Encuentas } from './encuentas';

describe('Encuentas', () => {
  it('should create an instance', () => {
    expect(new Encuentas()).toBeTruthy();
  });
});
