import { Preguntas } from './preguntas';

describe('Preguntas', () => {
  it('should create an instance', () => {
    expect(new Preguntas()).toBeTruthy();
  });
});
