import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEncuestasComponent } from './add-encuestas.component';

describe('AddEncuestasComponent', () => {
  let component: AddEncuestasComponent;
  let fixture: ComponentFixture<AddEncuestasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddEncuestasComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddEncuestasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
